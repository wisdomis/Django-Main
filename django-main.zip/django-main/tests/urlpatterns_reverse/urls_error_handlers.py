# Used by the ErrorHandlerResolutionTests test case.

urlpatterns = []

handler400 = "urlpatterns_reverse.views.empty_view"
handler403 = "urlpatterns_reverse.views.empty_view"
handler404 = "urlpatterns_reverse.views.empty_view"
handler500 = "urlpatterns_reverse.views.empty_view"
