from django.db import models


class Thing(models.Model):
    num = models.IntegerField()
