from django.contrib import admin


class CustomAdminSite(admin.AdminSite):
    pass
