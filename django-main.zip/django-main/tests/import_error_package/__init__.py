# A package that raises an ImportError that can be shared among test apps and
# excluded from test discovery.
raise ImportError("Oops")
